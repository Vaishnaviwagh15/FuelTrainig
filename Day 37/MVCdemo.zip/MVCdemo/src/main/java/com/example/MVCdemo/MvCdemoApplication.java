package com.example.MVCdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvCdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvCdemoApplication.class, args);
	}

}
