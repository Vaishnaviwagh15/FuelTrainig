package com.example.UsingUsersPassword;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsingUsersPasswordApplicationTests {

	@Test
	void contextLoads() {
	}

}
