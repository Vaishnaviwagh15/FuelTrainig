package com.example.UsingUsersPassword;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsingUsersPasswordApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsingUsersPasswordApplication.class, args);
	}

}
