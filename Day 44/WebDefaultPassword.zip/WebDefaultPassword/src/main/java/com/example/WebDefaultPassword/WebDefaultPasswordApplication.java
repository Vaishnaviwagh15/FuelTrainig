package com.example.WebDefaultPassword;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebDefaultPasswordApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebDefaultPasswordApplication.class, args);
	}

}
