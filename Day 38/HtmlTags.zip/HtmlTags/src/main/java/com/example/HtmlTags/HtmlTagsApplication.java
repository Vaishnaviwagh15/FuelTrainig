package com.example.HtmlTags;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlTagsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlTagsApplication.class, args);
	}

}
